# src/geo_recsys_simple_lib/lib.py
import joblib
import numpy as np
import pandas as pd
from typing import List
from pathlib import Path

from sklearn.neighbors import NearestNeighbors
from sklearn.base import TransformerMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.exceptions import NotFittedError
from huggingface_hub import hf_hub_download

from .types import GeoCoordinates, GeoSearchQuery, GeoSearchResult, GeoSearchResults

class GeoNearestNeighbors(NearestNeighbors, TransformerMixin):
    """
    Geographic nearest neighbors search using scikit-learn's Haversine metric
    """
    
    # Fixed column names
    DESCRIPTION_COL = 'description'
    START_LAT_COL = 'start_latitude'
    START_LON_COL = 'start_longitude'
    END_LAT_COL = 'end_latitude'
    END_LON_COL = 'end_longitude'
    
    EARTH_RADIUS_METERS = 6371000.0
    
    def __init__(
        self,
        metric: str = 'haversine',
        algorithm: str = 'ball_tree',
        leaf_size: int = 30,
        n_jobs: int = -1
    ):
        super().__init__(
            metric=metric,
            algorithm=algorithm,
            leaf_size=leaf_size,
            n_jobs=n_jobs
        )

    def fit(self, data: pd.DataFrame) -> "GeoNearestNeighbors":
        """Fit the model with route data."""
        # Validate required columns
        required_cols = [
            self.DESCRIPTION_COL, self.START_LAT_COL, self.START_LON_COL,
            self.END_LAT_COL, self.END_LON_COL
        ]
        missing_cols = [col for col in required_cols if col not in data.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
        
        # Validate coordinates using GeoCoordinates
        for idx, row in data.iterrows():
            try:
                GeoCoordinates(latitude=row[self.START_LAT_COL], longitude=row[self.START_LON_COL])
                GeoCoordinates(latitude=row[self.END_LAT_COL], longitude=row[self.END_LON_COL])
            except Exception as e:
                raise ValueError(f"Invalid coordinates at row {idx}: {e}")
                
        # Store data
        self.data_ = data[required_cols].copy()
                
        # Create coordinate array and transform to radians
        coords = np.column_stack((
            data[self.START_LAT_COL].astype(np.float64),
            data[self.START_LON_COL].astype(np.float64)
        ))
        coords_rad = self.transform(coords)
                
        # Fit sklearn model
        super().fit(coords_rad)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        """
        Transform coordinates from degrees to radians.
        
        Args:
            X: numpy array of coordinates
        
        Returns:
            Coordinates in radians
        """
        X = np.asarray(X)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        return np.radians(X)

    def predict(self, X: GeoSearchQuery) -> GeoSearchResults:
        """
        Search for routes within geographic radius.
        
        Args:
            X: GeoSearchQuery object
            
        Returns:
            GeoSearchResults with validated route data
        """
        check_is_fitted(self, ['data_'])
        
        # Transform coordinates to radians
        coords_array = X.coordinates.to_array()
        coords_rad = self.transform(coords_array)
        
        # Convert radius to radians
        radius_rad = X.radius_meters / self.EARTH_RADIUS_METERS
        
        # Find neighbors within radius
        distances_rad, indices = self.radius_neighbors(
            coords_rad, radius=radius_rad, return_distance=True
        )
        
        # Convert back to meters and sort
        distances_m = distances_rad[0] * self.EARTH_RADIUS_METERS
        results = list(zip(indices[0], distances_m))
        results.sort(key=lambda x: x[1])
        
        return self._format_results(results)

    def _format_results(self, results: List[tuple]) -> GeoSearchResults:
        """Format search results with route details and validation."""
        formatted_results = []
        for idx, dist in results:
            row = self.data_.iloc[idx]
            
            result = GeoSearchResult(
                index=int(idx),
                description=str(row[self.DESCRIPTION_COL]),
                start_coordinates=GeoCoordinates(
                    latitude=float(row[self.START_LAT_COL]),
                    longitude=float(row[self.START_LON_COL])
                ),
                end_coordinates=GeoCoordinates(
                    latitude=float(row[self.END_LAT_COL]),
                    longitude=float(row[self.END_LON_COL])
                ),
                geo_distance=float(round(dist, 2))
            )
            formatted_results.append(result)
        
        return GeoSearchResults(
            results=formatted_results,
            total_found=len(formatted_results)
        )

    def __call__(self, X: GeoSearchQuery) -> GeoSearchResults:
        """
        Make the model callable - alias for predict method.
        
        Args:
            X: GeoSearchQuery object
            
        Returns:
            GeoSearchResults with validated route data
        """
        return self.predict(X)

    def save_model(self, filepath: str = "models/geo_nearest_neighbors.joblib") -> None:
        """Save complete model state."""
        try:
            check_is_fitted(self, ['data_'])
        except NotFittedError:
            raise ValueError("Model must be fitted before saving")
                
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, filepath, compress=3)

    def load_model(self, filepath: str = "models/geo_nearest_neighbors.joblib") -> "GeoNearestNeighbors":
        """Load model state into current instance."""
        loaded_model = joblib.load(filepath)
        self.__dict__.update(loaded_model.__dict__)
        return self

    @classmethod
    def from_file(cls, filepath: str = "models/geo_nearest_neighbors.joblib") -> "GeoNearestNeighbors":
        """Create instance from saved file."""
        return joblib.load(filepath)

    @classmethod
    def from_huggingface_hub(
        cls, 
        repo_id: str, 
        filename: str = "models/geo_nearest_neighbors.joblib",
        cache_dir: str = "models/",
        force_download: bool = False,
        token: str = None
    ) -> "GeoNearestNeighbors":
        """
        Download and load model from Hugging Face Hub.
        
        Args:
            repo_id: Repository ID on Hugging Face Hub (e.g., "username/model-name")
            filename: Name of the model file in the repository
            cache_dir: Directory to cache downloaded files
            force_download: Whether to force re-download even if cached
            token: Hugging Face token for private repositories (optional)
            
        Returns:
            GeoNearestNeighbors instance loaded from Hub
        """
        try:
            # Download model file from Hub
            model_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                cache_dir=cache_dir,
                force_download=force_download,
                token=token
            )
            
            # Load and return the model
            return joblib.load(model_path)
            
        except Exception as e:
            raise RuntimeError(f"Failed to download model from Hugging Face Hub: {e}")